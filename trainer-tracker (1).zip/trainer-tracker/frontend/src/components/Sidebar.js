import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const navItems = {
  admin: [
    { to: '/admin',          icon: '▦',  label: 'Overview'   },
    { to: '/admin/trainers', icon: '👥', label: 'Trainers'   },
    { to: '/admin/schedule', icon: '📅', label: 'Schedules'  },
    { to: '/admin/sheets',   icon: '📊', label: 'Sheets Sync' },
  ],
  employee: [
    { to: '/dashboard',      icon: '▦',  label: 'My Slots'   },
    { to: '/dashboard/history', icon: '📅', label: 'History' },
  ],
};

export default function Sidebar({ collapsed, setCollapsed }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const items = navItems[user?.role] || [];

  return (
    <aside style={{
      width: collapsed ? 64 : 220,
      minHeight: '100vh',
      background: '#0d1520',
      borderRight: '1px solid #1a2535',
      display: 'flex',
      flexDirection: 'column',
      transition: 'width 0.25s cubic-bezier(0.4,0,0.2,1)',
      overflow: 'hidden',
      flexShrink: 0,
    }}>
      {/* Header */}
      <div style={{ padding: collapsed ? '20px 0' : '20px 16px', display: 'flex', alignItems: 'center', gap: 10, borderBottom: '1px solid #1a2535', justifyContent: collapsed ? 'center' : 'space-between' }}>
        {!collapsed && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <div style={{ width: 28, height: 28, borderRadius: 7, background: 'linear-gradient(135deg, #3b82f6, #6366f1)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 14, flexShrink: 0 }}>⚡</div>
            <span style={{ color: '#f1f5f9', fontWeight: 700, fontSize: 14, whiteSpace: 'nowrap' }}>TrainerTrack</span>
          </div>
        )}
        <button
          onClick={() => setCollapsed(!collapsed)}
          style={{ background: 'none', border: 'none', color: '#475569', cursor: 'pointer', fontSize: 16, padding: 4, lineHeight: 1 }}
        >
          {collapsed ? '›' : '‹'}
        </button>
      </div>

      {/* User badge */}
      {!collapsed && (
        <div style={{ margin: '12px 12px 4px', background: '#111827', borderRadius: 8, padding: '10px 12px', border: '1px solid #1a2535' }}>
          <div style={{ color: '#f1f5f9', fontSize: 12, fontWeight: 600, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{user?.name}</div>
          <div style={{ color: '#3b82f6', fontSize: 11, marginTop: 2, textTransform: 'uppercase', letterSpacing: '0.06em' }}>{user?.role}</div>
        </div>
      )}

      {/* Nav */}
      <nav style={{ flex: 1, padding: '8px 8px', display: 'flex', flexDirection: 'column', gap: 2 }}>
        {items.map(item => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.to === '/admin' || item.to === '/dashboard'}
            style={({ isActive }) => ({
              display: 'flex',
              alignItems: 'center',
              gap: 10,
              padding: collapsed ? '10px 0' : '9px 12px',
              borderRadius: 8,
              textDecoration: 'none',
              color: isActive ? '#60a5fa' : '#64748b',
              background: isActive ? 'rgba(59,130,246,0.08)' : 'transparent',
              fontSize: 13,
              fontWeight: isActive ? 600 : 400,
              transition: 'all 0.15s',
              justifyContent: collapsed ? 'center' : 'flex-start',
              whiteSpace: 'nowrap',
            })}
            onMouseEnter={e => { if (!e.currentTarget.classList.contains('active')) { e.currentTarget.style.background = 'rgba(255,255,255,0.04)'; e.currentTarget.style.color = '#94a3b8'; }}}
            onMouseLeave={e => { e.currentTarget.style.background = ''; e.currentTarget.style.color = ''; }}
          >
            <span style={{ fontSize: collapsed ? 17 : 15, flexShrink: 0 }}>{item.icon}</span>
            {!collapsed && <span>{item.label}</span>}
          </NavLink>
        ))}
      </nav>

      {/* Logout */}
      <div style={{ padding: '12px 8px', borderTop: '1px solid #1a2535' }}>
        <button
          onClick={() => { logout(); navigate('/login'); }}
          style={{ width: '100%', display: 'flex', alignItems: 'center', gap: 10, padding: collapsed ? '10px 0' : '9px 12px', borderRadius: 8, background: 'none', border: 'none', color: '#64748b', cursor: 'pointer', fontSize: 13, justifyContent: collapsed ? 'center' : 'flex-start', transition: 'all 0.15s' }}
          onMouseEnter={e => { e.currentTarget.style.color = '#f87171'; e.currentTarget.style.background = 'rgba(239,68,68,0.06)'; }}
          onMouseLeave={e => { e.currentTarget.style.color = '#64748b'; e.currentTarget.style.background = 'none'; }}
        >
          <span style={{ fontSize: collapsed ? 17 : 15 }}>⎋</span>
          {!collapsed && <span>Logout</span>}
        </button>
      </div>
    </aside>
  );
}
