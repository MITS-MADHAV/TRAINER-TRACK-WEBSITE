import React, { useState } from 'react';

const STATUS_CONFIG = {
  'Pending':     { color: '#64748b', bg: 'rgba(100,116,139,0.1)',  border: 'rgba(100,116,139,0.2)', dot: '#64748b' },
  'In Progress': { color: '#f59e0b', bg: 'rgba(245,158,11,0.08)',  border: 'rgba(245,158,11,0.2)', dot: '#f59e0b' },
  'Done':        { color: '#10b981', bg: 'rgba(16,185,129,0.08)',  border: 'rgba(16,185,129,0.2)', dot: '#10b981' },
  'Delayed':     { color: '#ef4444', bg: 'rgba(239,68,68,0.08)',   border: 'rgba(239,68,68,0.2)',  dot: '#ef4444' },
  'Break':       { color: '#8b5cf6', bg: 'rgba(139,92,246,0.08)',  border: 'rgba(139,92,246,0.2)', dot: '#8b5cf6' },
};

const STATUSES = ['Pending', 'In Progress', 'Done', 'Delayed', 'Break'];

export default function SlotCard({ slot, onSave, readOnly, adminMode }) {
  const [editing, setEditing]   = useState(false);
  const [taskName, setTaskName] = useState(slot.taskName || '');
  const [status, setStatus]     = useState(slot.status || 'Pending');
  const [remarks, setRemarks]   = useState(slot.remarks || '');
  const [saving, setSaving]     = useState(false);

  const isBreak = slot.slotNumber === 5 && !adminMode;
  const cfg = STATUS_CONFIG[status] || STATUS_CONFIG['Pending'];

  async function handleSave() {
    setSaving(true);
    try {
      await onSave({ slotNumber: slot.slotNumber, taskName, status, remarks });
      setEditing(false);
    } catch (e) {
      console.error(e);
    } finally {
      setSaving(false);
    }
  }

  function handleCancel() {
    setTaskName(slot.taskName || '');
    setStatus(slot.status || 'Pending');
    setRemarks(slot.remarks || '');
    setEditing(false);
  }

  const timeSlots = ['9:00–9:45', '9:45–10:30', '10:30–11:15', '11:15–12:00', '12:00–12:45', '12:45–13:30', '13:30–14:15', '14:15–15:00', '15:00–15:45'];

  return (
    <div style={{
      background: editing ? '#111827' : '#0f1923',
      border: `1px solid ${editing ? '#1e3a5f' : '#1a2535'}`,
      borderRadius: 12,
      padding: 16,
      transition: 'all 0.2s',
      position: 'relative',
      overflow: 'hidden',
    }}>
      {/* Status stripe */}
      <div style={{ position: 'absolute', top: 0, left: 0, width: 3, height: '100%', background: cfg.dot, borderRadius: '3px 0 0 3px' }} />

      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10, paddingLeft: 6 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <div style={{ background: 'rgba(59,130,246,0.1)', border: '1px solid rgba(59,130,246,0.15)', borderRadius: 6, padding: '2px 8px', color: '#60a5fa', fontSize: 11, fontWeight: 700, letterSpacing: '0.05em' }}>
            SLOT {slot.slotNumber}
          </div>
          <span style={{ color: '#374151', fontSize: 11 }}>{timeSlots[slot.slotNumber - 1]}</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4, background: cfg.bg, border: `1px solid ${cfg.border}`, borderRadius: 20, padding: '2px 8px', color: cfg.color, fontSize: 11, fontWeight: 500 }}>
            <span style={{ width: 5, height: 5, borderRadius: '50%', background: cfg.dot, display: 'inline-block' }} />
            {status}
          </span>
          {!readOnly && !isBreak && !editing && (
            <button
              onClick={() => setEditing(true)}
              style={{ background: 'rgba(59,130,246,0.08)', border: '1px solid rgba(59,130,246,0.2)', borderRadius: 6, color: '#60a5fa', padding: '3px 8px', fontSize: 11, cursor: 'pointer' }}
            >
              Edit
            </button>
          )}
        </div>
      </div>

      {/* Content */}
      <div style={{ paddingLeft: 6 }}>
        {editing ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            <input
              value={taskName}
              onChange={e => setTaskName(e.target.value)}
              placeholder="Task name..."
              style={{ width: '100%', padding: '8px 10px', background: '#0a0e1a', border: '1px solid #1e2a3a', borderRadius: 6, color: '#f1f5f9', fontSize: 13, outline: 'none', boxSizing: 'border-box' }}
              onFocus={e => e.target.style.borderColor = '#3b82f6'}
              onBlur={e => e.target.style.borderColor = '#1e2a3a'}
            />
            <select
              value={status}
              onChange={e => setStatus(e.target.value)}
              style={{ width: '100%', padding: '8px 10px', background: '#0a0e1a', border: '1px solid #1e2a3a', borderRadius: 6, color: '#f1f5f9', fontSize: 13, outline: 'none', cursor: 'pointer' }}
            >
              {STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
            <textarea
              value={remarks}
              onChange={e => setRemarks(e.target.value)}
              placeholder="Add remarks..."
              rows={2}
              style={{ width: '100%', padding: '8px 10px', background: '#0a0e1a', border: '1px solid #1e2a3a', borderRadius: 6, color: '#f1f5f9', fontSize: 13, outline: 'none', resize: 'none', boxSizing: 'border-box', fontFamily: 'inherit' }}
              onFocus={e => e.target.style.borderColor = '#3b82f6'}
              onBlur={e => e.target.style.borderColor = '#1e2a3a'}
            />
            <div style={{ display: 'flex', gap: 8 }}>
              <button
                onClick={handleSave}
                disabled={saving}
                style={{ flex: 1, padding: '8px', background: saving ? '#1e3a5f' : 'linear-gradient(135deg, #3b82f6, #2563eb)', border: 'none', borderRadius: 6, color: '#fff', fontSize: 12, fontWeight: 600, cursor: saving ? 'not-allowed' : 'pointer' }}
              >
                {saving ? 'Saving…' : '✓ Save'}
              </button>
              <button
                onClick={handleCancel}
                style={{ padding: '8px 14px', background: 'rgba(255,255,255,0.04)', border: '1px solid #1a2535', borderRadius: 6, color: '#64748b', fontSize: 12, cursor: 'pointer' }}
              >
                Cancel
              </button>
            </div>
          </div>
        ) : (
          <div>
            <div style={{ color: taskName ? '#e2e8f0' : '#374151', fontSize: 14, fontWeight: taskName ? 500 : 400, marginBottom: remarks ? 6 : 0, fontStyle: taskName ? 'normal' : 'italic' }}>
              {taskName || 'No task assigned'}
            </div>
            {remarks && (
              <div style={{ color: '#475569', fontSize: 12, borderLeft: '2px solid #1e2a3a', paddingLeft: 8, marginTop: 6 }}>{remarks}</div>
            )}
            {slot.updatedAt && (
              <div style={{ color: '#1e3a5f', fontSize: 10, marginTop: 8 }}>
                Updated {new Date(slot.updatedAt).toLocaleTimeString()}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
