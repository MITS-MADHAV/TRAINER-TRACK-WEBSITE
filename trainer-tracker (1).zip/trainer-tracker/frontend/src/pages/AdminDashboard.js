import React, { useEffect, useState } from 'react';
import { API } from '../context/AuthContext';

function StatCard({ label, value, color, icon, sub }) {
  return (
    <div style={{ background: '#111827', border: '1px solid #1a2535', borderRadius: 14, padding: '20px 24px', flex: 1, minWidth: 140 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div>
          <div style={{ color: '#475569', fontSize: 12, textTransform: 'uppercase', letterSpacing: '0.07em', marginBottom: 10 }}>{label}</div>
          <div style={{ fontSize: 32, fontWeight: 700, color }}>{value}</div>
          {sub && <div style={{ color: '#374151', fontSize: 12, marginTop: 4 }}>{sub}</div>}
        </div>
        <div style={{ width: 40, height: 40, borderRadius: 10, background: `${color}12`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20 }}>{icon}</div>
      </div>
    </div>
  );
}

function TrainerRow({ trainer, onEditSlot }) {
  const donePercent = trainer.slots.length > 0 ? Math.round((trainer.done / (trainer.slots.length - 1)) * 100) : 0;
  const [expanded, setExpanded] = useState(false);

  return (
    <div style={{ background: '#111827', border: '1px solid #1a2535', borderRadius: 12, overflow: 'hidden', transition: 'border-color 0.2s' }}>
      <div
        onClick={() => setExpanded(!expanded)}
        style={{ padding: '14px 20px', display: 'flex', alignItems: 'center', gap: 16, cursor: 'pointer' }}
      >
        <div style={{ width: 36, height: 36, borderRadius: '50%', background: 'linear-gradient(135deg, #3b82f6, #6366f1)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 700, fontSize: 14, flexShrink: 0 }}>
          {trainer.name[0]}
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ color: '#e2e8f0', fontSize: 14, fontWeight: 500 }}>{trainer.name}</div>
          <div style={{ color: '#475569', fontSize: 12 }}>{trainer.email}</div>
        </div>
        <div style={{ display: 'flex', gap: 12, alignItems: 'center', flexWrap: 'wrap' }}>
          <span style={{ color: '#10b981', fontSize: 12 }}>✅ {trainer.done}</span>
          <span style={{ color: '#f59e0b', fontSize: 12 }}>⚡ {trainer.inProgress}</span>
          <span style={{ color: '#ef4444', fontSize: 12 }}>⚠ {trainer.delayed}</span>
          <div style={{ width: 80, height: 5, background: '#1a2535', borderRadius: 3, overflow: 'hidden' }}>
            <div style={{ height: '100%', width: `${donePercent}%`, background: 'linear-gradient(90deg, #3b82f6, #10b981)', borderRadius: 3 }} />
          </div>
          <span style={{ color: '#60a5fa', fontSize: 11, width: 32, textAlign: 'right' }}>{donePercent}%</span>
          <span style={{ color: '#374151', fontSize: 14 }}>{expanded ? '▲' : '▼'}</span>
        </div>
      </div>

      {expanded && (
        <div style={{ borderTop: '1px solid #1a2535', padding: '16px 20px' }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))', gap: 10 }}>
            {trainer.slots.map(slot => (
              <AdminSlotMini key={slot.slotNumber} slot={slot} trainerName={trainer.name} onEdit={onEditSlot} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function AdminSlotMini({ slot, trainerName, onEdit }) {
  const STATUS_COLORS = { 'Done': '#10b981', 'In Progress': '#f59e0b', 'Pending': '#64748b', 'Delayed': '#ef4444', 'Break': '#8b5cf6' };
  const color = STATUS_COLORS[slot.status] || '#64748b';
  return (
    <div style={{ background: '#0d1520', border: `1px solid #1a2535`, borderRadius: 8, padding: '10px 12px', borderLeft: `3px solid ${color}` }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
        <span style={{ color: '#60a5fa', fontSize: 11, fontWeight: 700 }}>SLOT {slot.slotNumber}</span>
        <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
          <span style={{ color, fontSize: 11 }}>{slot.status}</span>
          <button onClick={() => onEdit(trainerName, slot)} style={{ background: 'rgba(59,130,246,0.1)', border: '1px solid rgba(59,130,246,0.2)', borderRadius: 4, color: '#60a5fa', padding: '1px 6px', fontSize: 10, cursor: 'pointer' }}>Edit</button>
        </div>
      </div>
      <div style={{ color: slot.taskName ? '#94a3b8' : '#374151', fontSize: 12, fontStyle: slot.taskName ? 'normal' : 'italic' }}>
        {slot.taskName || 'No task'}
      </div>
    </div>
  );
}

function EditModal({ data, onClose, onSave }) {
  const [taskName, setTaskName] = useState(data.slot.taskName || '');
  const [status, setStatus]     = useState(data.slot.status || 'Pending');
  const [remarks, setRemarks]   = useState(data.slot.remarks || '');
  const [saving, setSaving]     = useState(false);

  async function handleSave() {
    setSaving(true);
    await onSave({ trainerName: data.trainerName, slotNumber: data.slot.slotNumber, taskName, status, remarks });
    setSaving(false);
    onClose();
  }

  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.7)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000 }} onClick={onClose}>
      <div style={{ background: '#111827', border: '1px solid #1e2a3a', borderRadius: 16, padding: 28, width: 420, maxWidth: '90vw' }} onClick={e => e.stopPropagation()}>
        <h3 style={{ color: '#f1f5f9', margin: '0 0 4px', fontSize: 16, fontWeight: 600 }}>Edit Slot {data.slot.slotNumber}</h3>
        <p style={{ color: '#475569', fontSize: 12, margin: '0 0 20px' }}>Trainer: {data.trainerName}</p>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <input value={taskName} onChange={e => setTaskName(e.target.value)} placeholder="Task name..." style={{ padding: '10px 12px', background: '#0a0e1a', border: '1px solid #1e2a3a', borderRadius: 8, color: '#f1f5f9', fontSize: 13, outline: 'none' }} />
          <select value={status} onChange={e => setStatus(e.target.value)} style={{ padding: '10px 12px', background: '#0a0e1a', border: '1px solid #1e2a3a', borderRadius: 8, color: '#f1f5f9', fontSize: 13, outline: 'none' }}>
            {['Pending','In Progress','Done','Delayed','Break'].map(s => <option key={s}>{s}</option>)}
          </select>
          <textarea value={remarks} onChange={e => setRemarks(e.target.value)} placeholder="Remarks..." rows={3} style={{ padding: '10px 12px', background: '#0a0e1a', border: '1px solid #1e2a3a', borderRadius: 8, color: '#f1f5f9', fontSize: 13, outline: 'none', resize: 'none', fontFamily: 'inherit' }} />
          <div style={{ display: 'flex', gap: 8, marginTop: 4 }}>
            <button onClick={handleSave} disabled={saving} style={{ flex: 1, padding: '10px', background: 'linear-gradient(135deg, #3b82f6, #2563eb)', border: 'none', borderRadius: 8, color: '#fff', fontSize: 13, fontWeight: 600, cursor: 'pointer' }}>
              {saving ? 'Saving…' : 'Save Changes'}
            </button>
            <button onClick={onClose} style={{ padding: '10px 16px', background: 'rgba(255,255,255,0.04)', border: '1px solid #1a2535', borderRadius: 8, color: '#64748b', fontSize: 13, cursor: 'pointer' }}>Cancel</button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function AdminDashboard() {
  const [stats, setStats]       = useState(null);
  const [trainers, setTrainers] = useState([]);
  const [date, setDate]         = useState(new Date().toISOString().split('T')[0]);
  const [editData, setEditData] = useState(null);
  const [loading, setLoading]   = useState(true);

  async function load() {
    setLoading(true);
    try {
      const [s, t] = await Promise.all([
        API.get(`/admin/stats?date=${date}`),
        API.get(`/admin/trainers?date=${date}`),
      ]);
      setStats(s.data);
      setTrainers(t.data.trainers);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  }

  useEffect(() => { load(); }, [date]);

  async function handleEditSave({ trainerName, slotNumber, taskName, status, remarks }) {
    await API.put('/admin/edit-slot', { trainerName, slotNumber, taskName, status, remarks, date });
    await load();
  }

  return (
    <div style={{ padding: '28px 32px', maxWidth: 1200, margin: '0 auto' }}>
      {editData && <EditModal data={editData} onClose={() => setEditData(null)} onSave={handleEditSave} />}

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 28, flexWrap: 'wrap', gap: 12 }}>
        <div>
          <h1 style={{ color: '#f1f5f9', fontSize: 22, fontWeight: 700, margin: 0 }}>Admin Overview</h1>
          <p style={{ color: '#475569', fontSize: 13, margin: '4px 0 0' }}>Monitor all trainer activity</p>
        </div>
        <input type="date" value={date} onChange={e => setDate(e.target.value)} style={{ padding: '8px 12px', background: '#111827', border: '1px solid #1a2535', borderRadius: 8, color: '#94a3b8', fontSize: 13, outline: 'none' }} />
      </div>

      {stats && (
        <div style={{ display: 'flex', gap: 14, marginBottom: 28, flexWrap: 'wrap' }}>
          <StatCard label="Total Trainers" value={stats.totalTrainers}  color="#60a5fa" icon="👥" />
          <StatCard label="Tasks Done"     value={stats.totalDone}      color="#10b981" icon="✅" />
          <StatCard label="In Progress"    value={stats.totalInProgress} color="#f59e0b" icon="⚡" />
          <StatCard label="Pending"        value={stats.totalPending}   color="#64748b" icon="⏳" />
          <StatCard label="Delayed"        value={stats.totalDelayed}   color="#ef4444" icon="⚠️" />
        </div>
      )}

      <div style={{ marginBottom: 16 }}>
        <h2 style={{ color: '#94a3b8', fontSize: 14, fontWeight: 500, margin: '0 0 14px', textTransform: 'uppercase', letterSpacing: '0.07em' }}>Trainer Breakdown</h2>
        {loading ? (
          <div style={{ color: '#475569', textAlign: 'center', padding: 60 }}>Loading…</div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {trainers.map(t => (
              <TrainerRow key={t.id} trainer={t} onEditSlot={(trainerName, slot) => setEditData({ trainerName, slot })} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
