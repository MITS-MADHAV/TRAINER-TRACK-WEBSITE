import React, { useEffect, useState } from 'react';
import { API } from '../context/AuthContext';

export default function SheetsPage() {
  const [info, setInfo]       = useState(null);
  const [loading, setLoading] = useState(true);

  async function loadInfo() {
    try {
      const { data } = await API.get('/sheets/info');
      setInfo(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { loadInfo(); }, []);

  async function handleDownload() {
    try {
      const token = localStorage.getItem('tt_token');
      const res   = await fetch('http://localhost:4000/admin/download-excel', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) { alert('No data file yet — save some slots first!'); return; }
      const blob = await res.blob();
      const url  = URL.createObjectURL(blob);
      const a    = document.createElement('a');
      a.href     = url;
      a.download = 'trainer-data.xlsx';
      a.click();
      URL.revokeObjectURL(url);
    } catch {
      alert('Download failed');
    }
  }

  const totalRows = info
    ? Object.values(info.rowCounts || {}).reduce((a, b) => a + b, 0)
    : 0;

  return (
    <div style={{ padding: '28px 32px', maxWidth: 860, margin: '0 auto' }}>
      <div style={{ marginBottom: 28 }}>
        <h1 style={{ color: '#f1f5f9', fontSize: 22, fontWeight: 700, margin: 0 }}>Excel Data Storage</h1>
        <p style={{ color: '#475569', fontSize: 13, margin: '4px 0 0' }}>
          All slot saves are automatically written to <code style={{ color: '#60a5fa', background: 'rgba(59,130,246,0.1)', padding: '1px 6px', borderRadius: 4 }}>trainer-data.xlsx</code> in your backend folder
        </p>
      </div>

      {/* Status banner */}
      <div style={{
        background: info?.exists ? 'rgba(16,185,129,0.06)' : 'rgba(245,158,11,0.06)',
        border: `1px solid ${info?.exists ? 'rgba(16,185,129,0.2)' : 'rgba(245,158,11,0.2)'}`,
        borderRadius: 12, padding: '14px 20px', marginBottom: 24,
        display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 12,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <span style={{ fontSize: 22 }}>{info?.exists ? '✅' : '⏳'}</span>
          <div>
            <div style={{ color: info?.exists ? '#10b981' : '#f59e0b', fontSize: 13, fontWeight: 600 }}>
              {loading ? 'Checking…' : info?.exists ? 'Excel file active — auto-saving on every slot update' : 'Excel file will be created on first slot save'}
            </div>
            {info?.exists && (
              <div style={{ color: '#475569', fontSize: 12, marginTop: 2 }}>
                {totalRows} total rows saved across all slot sheets
              </div>
            )}
          </div>
        </div>
        <button
          onClick={handleDownload}
          style={{
            padding: '9px 18px', background: 'linear-gradient(135deg, #3b82f6, #2563eb)',
            border: 'none', borderRadius: 8, color: '#fff', fontSize: 13,
            fontWeight: 600, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6,
          }}
        >
          ⬇ Download Excel
        </button>
      </div>

      {/* Row counts per slot */}
      {info?.exists && (
        <div style={{ background: '#111827', border: '1px solid #1a2535', borderRadius: 14, padding: 24, marginBottom: 20 }}>
          <h3 style={{ color: '#e2e8f0', fontSize: 14, fontWeight: 600, margin: '0 0 16px', textTransform: 'uppercase', letterSpacing: '0.06em' }}>
            Rows Saved Per Sheet
          </h3>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(130px, 1fr))', gap: 10 }}>
            {Object.entries(info.rowCounts || {}).map(([sheet, count]) => (
              <div key={sheet} style={{ background: '#0d1520', border: '1px solid #1a2535', borderRadius: 8, padding: '12px 14px' }}>
                <div style={{ color: '#60a5fa', fontSize: 11, fontWeight: 700, marginBottom: 4 }}>{sheet}</div>
                <div style={{ color: count > 0 ? '#10b981' : '#374151', fontSize: 20, fontWeight: 700 }}>{count}</div>
                <div style={{ color: '#374151', fontSize: 10 }}>rows</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* How it works */}
      <div style={{ background: '#111827', border: '1px solid #1a2535', borderRadius: 14, padding: 24, marginBottom: 20 }}>
        <h3 style={{ color: '#e2e8f0', fontSize: 14, fontWeight: 600, margin: '0 0 16px', textTransform: 'uppercase', letterSpacing: '0.06em' }}>How It Works</h3>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          {[
            { icon: '💾', title: 'Auto-Save on Every Click', desc: 'When a trainer or admin clicks Save on any slot, the row is instantly written to trainer-data.xlsx in the backend folder.' },
            { icon: '🔄', title: 'Update in Place', desc: 'If you save the same slot again (same trainer + date + slot number), it updates the existing row — no duplicates.' },
            { icon: '📅', title: 'Full History', desc: 'Each date gets its own rows, so you have a complete day-by-day history of all trainer activity forever.' },
            { icon: '🔁', title: 'Survives Restarts', desc: 'When the server restarts, slot data is reloaded from the Excel file — no data loss.' },
            { icon: '📂', title: 'Open Anytime', desc: 'Open trainer-data.xlsx directly in Microsoft Excel or upload to Google Sheets anytime for analysis.' },
          ].map((item, i) => (
            <div key={i} style={{ display: 'flex', gap: 14, alignItems: 'flex-start' }}>
              <span style={{ fontSize: 20, flexShrink: 0, marginTop: 1 }}>{item.icon}</span>
              <div>
                <div style={{ color: '#e2e8f0', fontSize: 13, fontWeight: 500, marginBottom: 3 }}>{item.title}</div>
                <div style={{ color: '#64748b', fontSize: 12 }}>{item.desc}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Sheet structure */}
      <div style={{ background: '#111827', border: '1px solid #1a2535', borderRadius: 14, padding: 24 }}>
        <h3 style={{ color: '#e2e8f0', fontSize: 14, fontWeight: 600, margin: '0 0 14px', textTransform: 'uppercase', letterSpacing: '0.06em' }}>Column Structure (Each Sheet)</h3>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
          {['TRAINER NAME','DATE','SLOT','TASK NAME','DONE?','STATUS','REMARKS','UPDATED AT'].map((col, i) => (
            <span key={i} style={{ background: 'rgba(59,130,246,0.08)', border: '1px solid rgba(59,130,246,0.15)', borderRadius: 6, padding: '4px 10px', color: '#60a5fa', fontSize: 12, fontFamily: 'monospace' }}>
              {col}
            </span>
          ))}
        </div>
        <div style={{ color: '#374151', fontSize: 12, marginTop: 14 }}>
          File location: <code style={{ color: '#94a3b8', background: '#0a0e1a', padding: '2px 6px', borderRadius: 4 }}>backend/trainer-data.xlsx</code>
        </div>
      </div>
    </div>
  );
}
