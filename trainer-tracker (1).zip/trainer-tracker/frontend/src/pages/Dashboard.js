import React, { useEffect, useState } from 'react';
import { useAuth, API } from '../context/AuthContext';
import SlotCard from '../components/SlotCard';

function KpiCard({ label, value, color, icon }) {
  return (
    <div style={{ background: '#111827', border: '1px solid #1a2535', borderRadius: 12, padding: '16px 20px', flex: 1, minWidth: 120 }}>
      <div style={{ color: '#475569', fontSize: 11, textTransform: 'uppercase', letterSpacing: '0.07em', marginBottom: 8 }}>{label}</div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <span style={{ fontSize: 22 }}>{icon}</span>
        <span style={{ fontSize: 26, fontWeight: 700, color }}>{value}</span>
      </div>
    </div>
  );
}

export default function Dashboard() {
  const { user } = useAuth();
  const [slots, setSlots]       = useState([]);
  const [date, setDate]         = useState(new Date().toISOString().split('T')[0]);
  const [loading, setLoading]   = useState(true);
  const [saveMsg, setSaveMsg]   = useState('');

  async function loadSlots() {
    setLoading(true);
    try {
      const { data } = await API.get(`/slots?date=${date}`);
      const sorted = [...data.slots].sort((a, b) => a.slotNumber - b.slotNumber);
      setSlots(sorted);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { loadSlots(); }, [date]);

  async function handleSave({ slotNumber, taskName, status, remarks }) {
    await API.post('/slots/save', { slotNumber, taskName, status, remarks, date });
    setSaveMsg('Saved ✓');
    setTimeout(() => setSaveMsg(''), 2000);
    await loadSlots();
  }

  const done       = slots.filter(s => s.status === 'Done').length;
  const pending    = slots.filter(s => s.status === 'Pending').length;
  const inProgress = slots.filter(s => s.status === 'In Progress').length;
  const delayed    = slots.filter(s => s.status === 'Delayed').length;
  const progress   = slots.length > 0 ? Math.round((done / (slots.length - 1)) * 100) : 0;

  return (
    <div style={{ padding: '28px 32px', maxWidth: 1100, margin: '0 auto' }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 28, flexWrap: 'wrap', gap: 12 }}>
        <div>
          <h1 style={{ color: '#f1f5f9', fontSize: 22, fontWeight: 700, margin: 0 }}>My Daily Slots</h1>
          <p style={{ color: '#475569', fontSize: 13, margin: '4px 0 0' }}>Hello, {user?.name} 👋</p>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          {saveMsg && <span style={{ color: '#10b981', fontSize: 13, fontWeight: 500 }}>{saveMsg}</span>}
          <input
            type="date"
            value={date}
            onChange={e => setDate(e.target.value)}
            style={{ padding: '8px 12px', background: '#111827', border: '1px solid #1a2535', borderRadius: 8, color: '#94a3b8', fontSize: 13, outline: 'none', cursor: 'pointer' }}
          />
        </div>
      </div>

      {/* KPI row */}
      <div style={{ display: 'flex', gap: 12, marginBottom: 24, flexWrap: 'wrap' }}>
        <KpiCard label="Done"        value={done}       color="#10b981" icon="✅" />
        <KpiCard label="In Progress" value={inProgress} color="#f59e0b" icon="⚡" />
        <KpiCard label="Pending"     value={pending}    color="#64748b" icon="⏳" />
        <KpiCard label="Delayed"     value={delayed}    color="#ef4444" icon="⚠️" />
      </div>

      {/* Progress bar */}
      <div style={{ background: '#111827', border: '1px solid #1a2535', borderRadius: 10, padding: '14px 20px', marginBottom: 24 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
          <span style={{ color: '#94a3b8', fontSize: 13 }}>Today's Progress</span>
          <span style={{ color: '#60a5fa', fontSize: 13, fontWeight: 600 }}>{progress}%</span>
        </div>
        <div style={{ height: 6, background: '#1a2535', borderRadius: 3, overflow: 'hidden' }}>
          <div style={{ height: '100%', width: `${progress}%`, background: 'linear-gradient(90deg, #3b82f6, #10b981)', borderRadius: 3, transition: 'width 0.5s ease' }} />
        </div>
      </div>

      {/* Slots grid */}
      {loading ? (
        <div style={{ color: '#475569', textAlign: 'center', padding: 60 }}>Loading slots…</div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: 14 }}>
          {slots.map(slot => (
            <SlotCard key={slot.slotNumber} slot={slot} onSave={handleSave} readOnly={false} />
          ))}
        </div>
      )}
    </div>
  );
}
